# The Lost Landing

Static concept front-end for a new data product built on the Circle Jerks flight-event dataset.

## Purpose
Show Longmont's estimated opportunity cost from not charging landing or usage fees. The prototype includes:

- Interactive landing-fee calculator
- Daily, monthly, annual, 5-year and 10-year revenue estimates
- 30-day lost-revenue chart
- Aircraft ranking table
- Imaginary civic and airport projects funded by fees
- Art Deco World's Fair visual theme
- Data-method section designed around Circle Jerks fields

## Run locally
Open `index.html`, or serve the directory:

```bash
python3 -m http.server 8080
```

Then visit `http://localhost:8080`.

## Live-data integration
The current demo uses fixture values in `app.js`. Replace these with Circle Jerks API results. Recommended normalized endpoint:

```json
{
  "summary": {
    "operations_today": 300,
    "operations_30d": 9340,
    "touch_and_go_30d": 6740,
    "unique_aircraft_30d": 184,
    "outside_share": 0.72,
    "median_dwell_seconds": 252
  },
  "daily": [{"date":"2026-07-01","billable_events":278}],
  "aircraft": [{"tail":"N738BJ","events":63,"home_base":"Broomfield","operation":"Touch-and-go"}]
}
```

Keep operational facts separate from policy assumptions. The fee slider is explicitly an illustrative scenario, not a claim that every event is legally billable.

## Domain ideas

1. **LostLanding.org**
2. **RunwayRevenue.org**
3. **FairShareFlight.org**
4. **LandingLedger.org**
5. **LongmontLanding.org**
6. **RevenueOnTheRunway.org**
7. **ThePublicRunway.org**
8. **CirclesToCapital.org**
9. **AirfieldOpportunity.org**
10. **LMOLedger.org**

Recommended: **LostLanding.org** for the strongest campaign concept, or **LandingLedger.org** for a more neutral civic-data brand.
