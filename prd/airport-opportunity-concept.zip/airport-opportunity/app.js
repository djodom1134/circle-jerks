const $=s=>document.querySelector(s);
const fmt=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(n);
const compact=n=>new Intl.NumberFormat('en-US',{notation:'compact',maximumFractionDigits:2}).format(n);

const model={fee:10,daily:300,billable:1,days:365};
function recalc(){
  model.fee=+$ ('#fee').value; model.daily=+$ ('#daily').value; model.billable=+$ ('#billable').value/100; model.days=+$ ('#days').value;
  const annual=model.fee*model.daily*model.billable*model.days;
  $('#feeOut').textContent=fmt(model.fee); $('#dailyOut').textContent=model.daily; $('#billableOut').textContent=Math.round(model.billable*100)+'%'; $('#daysOut').textContent=model.days;
  $('#annual').textContent=fmt(annual); $('#monthly').textContent=fmt(annual/12); $('#perDay').textContent=fmt(annual/model.days); $('#fiveYear').textContent='$'+compact(annual*5); $('#tenYear').textContent='$'+compact(annual*10);
  $('#heroOps').textContent=Math.round(model.daily*model.days).toLocaleString(); $('#heroRevenue').textContent='$'+compact(annual);
  renderChart(); renderProjects(annual);
}
['fee','daily','billable','days'].forEach(id=>$('#'+id).addEventListener('input',recalc));
document.querySelectorAll('.preset').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.preset').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#fee').value=b.dataset.fee;recalc()}));

const dailyOps=[278,301,256,322,343,297,210,188,315,334,291,308,355,362,174,204,317,329,288,346,371,340,225,198,301,336,349,292,327,358];
function renderChart(){
 const svg=$('#barChart'); const max=Math.max(...dailyOps); const w=800,h=240,gap=5,bw=(w-gap*(dailyOps.length-1))/dailyOps.length;
 let total=0, html=''; dailyOps.forEach((ops,i)=>{const val=ops*model.billable*model.fee;total+=val;const bh=(ops/max)*185;const x=i*(bw+gap),y=220-bh;html+=`<rect x="${x}" y="${y}" width="${bw}" height="${bh}" rx="2" fill="${i===dailyOps.length-1?'#f4d37b':'#d9a441'}"><title>${ops} events · ${fmt(val)}</title></rect>`});
 html+=`<line x1="0" y1="220" x2="800" y2="220" stroke="#f4d37b" opacity=".45"/>`;svg.innerHTML=html;$('#thirtyTotal').textContent=fmt(total);
}

const aircraft=[
 {tail:'N738BJ',events:63,home:'Broomfield',pattern:'Touch-and-go'},
 {tail:'N842SP',events:52,home:'Boulder',pattern:'Low approach'},
 {tail:'N172LM',events:47,home:'Longmont',pattern:'Local training'},
 {tail:'N615MC',events:44,home:'Broomfield',pattern:'Touch-and-go'},
 {tail:'N904AT',events:39,home:'Centennial',pattern:'Pattern work'},
 {tail:'N221PA',events:35,home:'Erie',pattern:'Touch-and-go'}
];
function renderTable(){ $('#aircraftRows').innerHTML=aircraft.map(a=>`<tr><td><b>${a.tail}</b></td><td>${a.events}</td><td>${fmt(a.events*model.fee)}</td><td>${a.home}</td><td><span class="badge">${a.pattern}</span></td></tr>`).join('') }

const projects=[
 {icon:'🛬',name:'Taxiway Preservation Reserve',cost:2500000,desc:'Seal, repair, and preserve hard surfaces before failure turns maintenance into replacement.'},
 {icon:'⚡',name:'Electric Aviation Charging Apron',cost:850000,desc:'Charging, power management, and showcase infrastructure for quieter next-generation aircraft.'},
 {icon:'☕',name:'Community FBO & Café',cost:1800000,desc:'A destination terminal with meeting rooms, local food, exhibits, and public viewing terraces.'},
 {icon:'🔇',name:'Neighborhood Noise Sensor Network',cost:280000,desc:'Permanent calibrated monitors and a transparent public dashboard tied to aircraft tracks.'},
 {icon:'🌱',name:'Unleaded Fuel Transition Fund',cost:500000,desc:'Infrastructure and incentives that accelerate the move away from leaded aviation gasoline.'},
 {icon:'🏔️',name:'West Longmont Community Pavilion',cost:1200000,desc:'A civic gathering place funded by fair-use revenue from a public asset.'}
];
function renderProjects(annual){$('#projectGrid').innerHTML=projects.map(p=>{const years=p.cost/annual;const txt=years<1?`${Math.ceil(years*12)} months`:`${years.toFixed(1)} years`;return `<article class="project-card"><div class="project-icon">${p.icon}</div><h3>${p.name}</h3><div class="project-cost">${fmt(p.cost)}</div><p>${p.desc}</p><span class="fund-time">Funded in ${txt}</span></article>`}).join('')}

// Animated "today" counter: demo assumes observed events arrive evenly through local daytime.
function updateToday(){const now=new Date();const mins=now.getHours()*60+now.getMinutes();const active=Math.max(0,Math.min(1,(mins-360)/(20*60-360)));const events=Math.round(model.daily*active);$('#todayLost').textContent=fmt(events*model.billable*model.fee)}
setInterval(updateToday,15000);

recalc();renderTable();updateToday();
